## gizDuinoPatch1.6.x-1.8.x
From 'gizduino-' to 'gizDuino'

Version: 1.2
Update: Jun 20,2019

Release Notes: 06/20/19
   - boards.txt bug fixed
   - add LED_BUILTIN to sanguino variants
